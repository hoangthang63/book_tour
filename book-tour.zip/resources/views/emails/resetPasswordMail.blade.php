<!DOCTYPE html>
<html>
<head>
    <title>Book Tour</title>
</head>
<body>
    <h1>{{ $data['title'] }}</h1>
    <div>
        <p>Your new password is <strong>{{ $data['body'] }}</strong></p>
    </div>
</body>
</html>