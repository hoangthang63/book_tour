<!DOCTYPE html>
<html>
<head>
    <title>AllPHPTricks.com</title>
</head>
<body>
    <h1><?php echo e($data['title']); ?></h1>
    <p><?php echo e($data['body']); ?></p>
</body>
</html><?php /**PATH C:\laragon\www\book-tour\resources\views/emails/testMail.blade.php ENDPATH**/ ?>