<!DOCTYPE html>
<html>
<head>
    <title>Book Tour</title>
</head>
<body>
    <h1><?php echo e($data['title']); ?></h1>
    <div>
        <p>Your new password is <strong><?php echo e($data['body']); ?></strong></p>
    </div>
</body>
</html><?php /**PATH C:\laragon\www\book-tour\resources\views/emails/resetPasswordMail.blade.php ENDPATH**/ ?>