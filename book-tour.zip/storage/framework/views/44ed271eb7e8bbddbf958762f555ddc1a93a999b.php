
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header d-flex justify-content-between">
            <h4>Edit app</h4>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <form class="form-horizontal" action="<?php echo e(route('app.update',
            ['app' => $app->id_app])); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group row mb-3">
                    <label for="inputEmail3" class="col-3 col-form-label">Tên</label>
                    <div class="col-9">
                        <input type="text" class="form-control" name="name" value="">
                    </div>
                </div>
                <div class="form-group row mb-3">
                    <label for="inputEmail3" class="col-3 col-form-label">Logo</label>
                    <div class="col-9">
                        <input type="file" class="form-control" name="logo" value="">
                    </div>
                </div>

                <div class="form-group mb-0 justify-content-end row">
                    <div class="col-9">
                        <button type="submit" class="btn btn-info  ">Lưu</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('app'); ?>
    <style>
        .btn-outline-primary {
            pointer-events: none;
        }
    </style>
    <button type="button"
        class="btn btn-outline-primary mt-2"><?php echo e(session()->get('name_app') ? session()->get('name_app') : 'CGV'); ?> </button>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\book-tour\resources\views/app/edit_app.blade.php ENDPATH**/ ?>