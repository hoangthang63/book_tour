<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Thang</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
    <meta content="Coderthemes" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- App css -->
    <link href="<?php echo e(asset('css/icons.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/app-creative.min.css')); ?>" rel="stylesheet" type="text/css">
    <?php echo $__env->yieldPushContent('css'); ?>
</head>

<body data-layout="topnav" data-layout-config='{"layoutBoxed":false,"darkMode":false,"showRightSidebarOnStart": true}'>
    <!-- Begin page -->
    <div class="wrapper">

        <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->

        <div class="content-page">
            <div class="content">
                <!-- Topbar Start -->
                <?php echo $__env->make('user.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- end Topbar -->
                <?php echo $__env->make('user.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                <!-- Start Content-->
                <div class="container-fluid">
                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-left">
                                    <?php echo $__env->yieldContent('title'); ?>
                                    <div class="col-2 pt-2 d-flex">
                                        <?php echo $__env->yieldContent('list_app'); ?>
                                        <?php echo $__env->yieldContent('popup'); ?>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <!-- end page title -->
                        <div class="row">
                        </div>
                    </div>
                </div>

                <?php echo $__env->yieldContent('content'); ?>

                <!-- container -->

            </div>
            <!-- content -->

            <!-- Footer Start -->
            <?php echo $__env->make('user.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- end Footer -->

        </div>

        <!-- ============================================================== -->
        <!-- End Page content -->
        <!-- ============================================================== -->


    </div>
    <!-- END wrapper -->

    <!-- Right Sidebar -->

    <div class="rightbar-overlay"></div>
    <!-- /Right-bar -->

    <!-- bundle -->
    <script src="<?php echo e(asset('js/app.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor.min.js')); ?>"></script>
    <?php echo $__env->yieldContent('open_popup'); ?>
    <?php echo $__env->yieldContent('js'); ?>
    <?php echo $__env->yieldPushContent('js'); ?>
</body>

</html>
<?php /**PATH C:\laragon\www\book-tour\resources\views/user/master.blade.php ENDPATH**/ ?>